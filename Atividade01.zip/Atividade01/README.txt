Atividade Prática 01

Parte I

Para chamar a função utilizar: Resistor("cor1", "cor2", "cor3")
Cores disponíveis: "preto", "marrom", "vermelho", "laranja", "amarelo", "verde", "azul", "violeta", "cinza", "branco".

O script aceita que as cores sejam escritas com letras maiúsculas e/ou minúsculas, porém erros de digitação resultaram em erros.
Também resultará em erro passar um número diferente de 3 cores ou passar "preto" como a primeira cor.

O script Ex1.m mostra alguns exemplos das funcionalidades e erros do script, lembre-se de apertar ENTER ao rodar para passar para o próximo exemplo



Parte II

Para inicializar a resolução dos exercícios 1-5 deve-se utilizar: ExLaplaceETransf()

Conforme os exercícios são resolvidos é necessário apertar ENTER para inicializar a resolução do próximo

No exercício 3, o programa irá pedir para você passar o numerador e o denominador do polinômio para ele continuar os cálculos, estes podem ser passados de 3 formas:
- Número: 3 -> 3
- Lista: [2 1] -> 2s + 1
- conv: conv([2 1], [1 0 2]) -> (2s + 1) * (s^2 + 2)



Link do vídeo: https://www.youtube.com/watch?v=wrTP8wr7XNg


Luiz Felipe Picolo
Pedro Henrique Cordeiro Soares