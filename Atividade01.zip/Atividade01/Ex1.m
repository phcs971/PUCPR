Resistor("marrom", "verde");

input("")

Resistor("preto", "marrom", "verde");

input("")

Resistor("marrom", "verde", "azul");

input("")

Resistor("maRRom", "verDe", "Azul");

input("")

Resistor("m4rrom", "verde", "azul");